<?php
header("Content-type:text/calendar");
echo $_POST["data"];
?>